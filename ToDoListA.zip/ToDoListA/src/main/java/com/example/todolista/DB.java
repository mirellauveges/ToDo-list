package com.example.todolista;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;



public class DB {
    final String JDBC_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    final String URL = "jdbc:derby:phonebookDB;create=true";

    Connection conn = null;
    Statement createStatement = null;
    DatabaseMetaData dbmd = null;

    public DB() {
        try{
            conn = DriverManager.getConnection(URL);
            System.out.println("Successfully connected to the database.");
        }catch(Exception e){
            System.out.println("Failed to connect to the database.");
            System.out.println("" + e);
        }

        if(conn != null){
            try{
                createStatement = conn.createStatement();
            }catch(Exception e){
                System.out.println("" + e);
            }
        }

        try{
            dbmd = conn.getMetaData();
        }catch(Exception e){
            System.out.println("" + e);
        }

        try{
            ResultSet rs = dbmd.getTables(null, "APP", "ITEMS", null);
            if(!rs.next()){
                createStatement.execute("CREATE TABLE ITEMS(ID int PRIMARY KEY GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), NAME varchar(40), PRIORITY varchar(40), DATE varchar(40))");
                System.out.println("The table is successfully created.");
            }else{
                System.out.println("The table already exists.");
            }
        }catch(Exception e){
            System.out.println("The table is not created, because something went wrong.");
            System.out.println("" + e);
        }
    }

    public void addItem(Item i){
        try{
            PreparedStatement ps = conn.prepareStatement("INSERT INTO ITEMS (NAME, PRIORITY, DATE) VALUES (?, ?, ?)");
            ps.setString(1, i.getName());
            ps.setString(2, i.getPriority().toString());
            ps.setString(3,  i.getDate().toString());
            ps.execute();
            System.out.println("The new item is successfully added to the table.");
        }catch(Exception e){
            System.out.println("The new item is not added to the table.");
            System.out.println("" + e);
        }
    }

    public ObservableList<Item> getItems(){
        ObservableList<Item> items = null;
        try{
            items = FXCollections.observableArrayList();
            ResultSet rs = createStatement.executeQuery("SELECT * FROM ITEMS");
            while(rs.next()){
                Integer id = rs.getInt("ID");
                String name = rs.getString("NAME");
                Priority priority = switch (rs.getString("PRIORITY"))
                {
                    case "HIGH": yield Priority.HIGH;
                    case "NORMAL": yield Priority.NORMAL;
                    default: yield Priority.LOW;
                };
                LocalDate date = LocalDate.parse(rs.getString("DATE"));
                items.add(new Item(id, name, priority, date));
            }
        }catch(Exception e){
            System.out.println("Something went wrong during the query method.");
            System.out.println("" + e);
        }
        return items;
    }

    public void deleteItem(int id){
        try{
            PreparedStatement ps = conn.prepareStatement("DELETE FROM ITEMS WHERE ID = ?");
            ps.setInt(1, id+1);
            ps.execute();
        }catch(Exception e){
            System.out.println("Something went wrong during the delete method.");
            System.out.println("" + e);
        }
    }
/*
    public void updateContact(Person p){
        try{
            PreparedStatement ps = conn.prepareStatement("UPDATE CONTACTS SET NAME = ?, PHONE = ?, EMAIL = ? WHERE ID = ?");
            ps.setString(1, p.getName());
            ps.setString(2, p.getPhone());
            ps.setString(3, p.getEmail());
            ps.setInt(4, p.getId());
            ps.execute();
        }catch(Exception e){
            System.out.println("Something went wrong during the update.");
            System.out.println("" + e);
        }
    }
*/
}
