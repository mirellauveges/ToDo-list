module com.example.todolista {
    requires javafx.controls;
    requires javafx.fxml;
    requires itextpdf;
    requires java.sql;


    opens com.example.todolista to javafx.fxml;
    exports com.example.todolista;
}