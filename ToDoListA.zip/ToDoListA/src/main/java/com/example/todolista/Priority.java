package com.example.todolista;

public enum Priority {
    HIGH,
    NORMAL,
    LOW;

}
