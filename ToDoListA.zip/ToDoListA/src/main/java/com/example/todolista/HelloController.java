package com.example.todolista;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    private DB db = new DB();
    private static ObservableList<Item> items;

    @FXML
    private TableView<Item> todoTable;

    @FXML
    private TableColumn<Item, String> nameCol;

    @FXML
    private TableColumn<Item, Priority> priorityCol;

    @FXML
    private TableColumn<Item, String> dateCol;
    //private TableColumn<Item, Date> dateCol;
    @FXML
    private TextField newItemField;

    @FXML
    private ComboBox<Priority> priorityComboBox;

    @FXML
    private DatePicker dateField;

    @FXML
    private Label msgLabel;

    @FXML
    protected void save(){
        String name = newItemField.getText();
        Priority priority = priorityComboBox.getSelectionModel().getSelectedItem();
        LocalDate localDate = dateField.getValue();





        Item item = new Item(name, priority, localDate);
        todoTable.getItems().add(item);
        items.add(item);
        db.addItem(item);
    }

    @FXML
    protected void remove(){
        int idx = todoTable.getSelectionModel().getSelectedIndex();
        todoTable.getItems().remove(idx);
        items.remove(idx);
        db.deleteItem(idx);
    }

    @FXML
    protected void generateToPdf(){
        PDFGen pdfGen = new PDFGen();
        pdfGen.generatePDF("output", items);
        msgLabel.setTextFill(Color.rgb(0,0,0));
        msgLabel.setAlignment(Pos.CENTER);
        msgLabel.setText("Pdf generated successfully!");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        priorityComboBox.getItems().add(Priority.HIGH);
        priorityComboBox.getItems().add(Priority.NORMAL);
        priorityComboBox.getItems().add(Priority.LOW);

        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        priorityCol.setCellValueFactory(new PropertyValueFactory<>("priority"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        items = db.getItems();
        todoTable.getItems().addAll(items);

    }
}