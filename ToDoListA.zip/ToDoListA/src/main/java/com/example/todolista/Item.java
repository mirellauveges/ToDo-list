package com.example.todolista;

import java.time.LocalDate;
import java.util.Date;

public class Item {

    private int id;
    private String name;
    private Priority priority;
    //private Date date;
    private LocalDate date;

    public Item() {
    }
    public Item(int id, String name, Priority priority, LocalDate date) {
        this.id = id;
        this.name = name;
        this.priority = priority;
        this.date = date;
    }


    public Item(String name, Priority priority, LocalDate date) {
        this.name = name;
        this.priority = priority;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
}
