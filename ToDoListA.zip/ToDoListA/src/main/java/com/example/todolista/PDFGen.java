package com.example.todolista;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.collections.ObservableList;

import java.io.FileOutputStream;


public class PDFGen {
    public void generatePDF(String fileName, ObservableList<Item> text){
        Document pdf = new Document();
        try{
            PdfWriter.getInstance(pdf, new FileOutputStream("./outputFiles/" + fileName + ".pdf"));
            pdf.open();

            // Táblázat inicializálása
            float[] columnWidths = {1, 3, 3, 4};
            PdfPTable table = new PdfPTable(columnWidths);
            table.setWidthPercentage(100);

            // Fejléc 0. sora
            PdfPCell cell = new PdfPCell(new Phrase("ToDo List"));
            cell.setBackgroundColor(GrayColor.GRAYWHITE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setColspan(4);
            table.addCell(cell);

            // Fejléc 1. sora
            table.getDefaultCell().setBackgroundColor(new GrayColor(0.75f));
            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell("ID");
            table.addCell("Name");
            table.addCell("Priority");
            table.addCell("Date");
            table.setHeaderRows(1);

            // Kontakt lista felvitele a táblázatba
            table.getDefaultCell().setBackgroundColor(GrayColor.GRAYWHITE);
            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
            for(int i = 0; i < text.size(); i++){
                int act = i + 1;
                table.addCell("" + act);
                table.addCell(text.get(i).getName());
                table.addCell(text.get(i).getPriority().toString());
                table.addCell(text.get(i).getDate().toString());
            }

            pdf.add(table);
        }catch(Exception e){
            e.printStackTrace();
        }
        pdf.close();
    }
}
